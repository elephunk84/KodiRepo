# UpdateTool
Iain's Kodi Build Tool
A Kodi plugin developed to backup and install Iain's Kodi build.
